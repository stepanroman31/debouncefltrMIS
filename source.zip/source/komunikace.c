#include "komunikace.h"
#include "appStateLibrary.h"
#include "messengerMIS.h"
#include <stdio.h>

#define RTM_SEND_PERIOD_MS 50 
#define MSG_MAX_NUM 17 
#define RTM_RX_INTEGER_MSG_LENGTH 7 
#define COM_GO false

// === GLOBALNI STAVY PRO RTM MODUL ===
signed short rtmCommand = 0;
static unsigned short cntPerformCom = 0; 

static unsigned char rxMsg[MSG_MAX_NUM]; 
static unsigned char txMsgNum[MSG_MAX_NUM];
static unsigned char cmd3_state = 0;

// --- Inicializace (Volan� jednou z configApplication) ---
void configRTM(void) {
    initSendGetMessageUSB(); 
}
// --- Hlavn� funkce RTM (Volan� ka?dou 1 ms z runApplication) ---
void runRTMCommunication(void) {
    app_state_t *app_state = get_app_state_address();
    // 1. PRIJEM POVELU (Dek�dov�n� CMD z datov�ch bajt?)
    if (getMessageUSB(rxMsg, COM_GO) == true) {
        
        // Zpracujeme jen, pokud zpr�va m� spr�vnou d�lku a typ (INT Command)
        if ( (rxMsg[0] & RX_MESSAGE_LENGTH_MASK) == RTM_RX_INTEGER_MSG_LENGTH &&
             (rxMsg[MSG_LEN_IX] & RX_MESSAGE_TYPE_MASK) == RX_FROM__COMMAND_EDITOR ) 
        {
            // Povel je int16_t, za?�n� na indexu [1]
            signed short receivedCmd = bytesToInteger(&rxMsg[1]);
            
            if (receivedCmd >= 0 && receivedCmd <= 3) {
                rtmCommand = receivedCmd; 
            }
        }
    }
    // 2. ODESILANI DAT (perioda 40 ms)
    if (cntPerformCom++ >= RTM_SEND_PERIOD_MS) {
        cntPerformCom = 0;
        
        // Z�sk�n� dat z datov�ho modelu
        uint8_t switched_val = app_state->pwm_0.input;
        int16_t s1_val_int = app_state->button_s1.outputMemory ? 1 : 0;
        int16_t s2_val_int = app_state->button_s2.outputMemory ? 1 : 0;
        int16_t v9_val_int = app_state->decoder_0.isMin ? 1 : 0;
        int16_t v12_val_int = app_state->decoder_0.isMax ? 1 : 0;
        
        switch (rtmCommand) {
            
            case 1: // CMD(1): Potenciometr do grafu (1x int16_t)
            {
                txMsgNum[0] = 7; 
                integerToBytes((int16_t)switched_val, &txMsgNum[1]);
                integerToBytes(v9_val_int, &txMsgNum[3]);
                integerToBytes(v12_val_int, &txMsgNum[5]);
                sendMessageUSB(txMsgNum, COM_GO); 
                break;
            }

            case 2: // CMD(2): S1 a S2 do grafu (2x int16_t)
            {
                txMsgNum[0] = 5; 
                integerToBytes(s1_val_int, &txMsgNum[1]);
                integerToBytes(s2_val_int, &txMsgNum[3]);
                sendMessageUSB(txMsgNum, COM_GO);
                break;
            }

            case 3: // CMD(3): Do Table Terminalu
            {
                char buffer[40]; 
                switch (cmd3_state) 
                {
                    case 0: // Stav 0: Poslat Potenciometr
                        sprintf(buffer, "POT: %d", switched_val);
                        sendTableTerminalMessageUSB("1A", buffer); // Po?li do bu?ky A1
                        break;
                        
                    case 1: // Stav 1: Poslat S1
                        sprintf(buffer, "S1: %d", s1_val_int);// Naform�tuj jen ?�slo
                        sendTableTerminalMessageUSB("2A", buffer);
                        break;
                        
                    case 2: // Stav 2: Poslat S2
                        sprintf(buffer, "S2: %d", s2_val_int);
                        sendTableTerminalMessageUSB("3A", buffer);
                        break;
                    case 3:
                        sprintf(buffer, "V9: %d", v9_val_int);
                        sendTableTerminalMessageUSB("4A", buffer);
                        break;
                    case 4:
                        sprintf(buffer, "V12: %d", v12_val_int);
                        sendTableTerminalMessageUSB("5A", buffer);
                        break;
                }
                
                // Posun na dal?� stav pro p?�?t� 40ms cyklus
                cmd3_state++;
                if (cmd3_state > 4) { // Pokud jsme byli ve stavu 2, vr�t�me se na 0
                    cmd3_state = 0;
                }

                break; // Konec case 3
            }
                break;
            

            case 0: // CMD(0): Stop
            default:
                break; 
        }
    }
    
    
}

    