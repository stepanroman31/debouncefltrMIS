// dek_logic.c
#include "deklog.h"
#include "platformMIS32mk.h" // Pro setCoderLedLL/HL
#include "appStateLibrary.h" // NOV?: Pro z�pis stavu V9/V12

// Funkce recalculateR1 a getSwitchedOutput Z?ST�VAJ� STEJN� (jsou to jen v�po?ty)
uint8_t recalculateR1(int16_t potValue) {
    // Definice funkce, kterou linker hled�!
    
    // P?epo?et <-2047, 2047> na <0.0, 1.0>
    float normalized = ((float)potValue + 2047.0f) / 4094.0f;
    
    // Omezen� (clipping) pro bezpe?nost
    if (normalized < 0.0f) normalized = 0.0f;
    if (normalized > 1.0f) normalized = 1.0f;
    
    // P?epo?et <0.0, 1.0> na <0, 255>
    return (uint8_t)(normalized * 255.0f+0.5f);
}
uint8_t getSwitchedOutput(bool S2_output, uint8_t r1_recalc, uint8_t s9_counter) {
    if (S2_output == true) { // LED V2 sv�t� -> Pou?ij S9
        return s9_counter; 
    } else { // LED V2 nesv�t� -> Pou?ij R1
        return r1_recalc; 
    }
}

// Tuto funkci uprav�me, aby zapisovala do appState
void runLimitIndicators(uint8_t switched_val) {
    // Z�sk�me ukazatel na datab�zi
    app_state_t *app_state = get_app_state_address();

    bool led_v9_state = (switched_val == 0);
    bool led_v12_state = (switched_val == 255);

    // 1. Nastaven� hardwarov�ch LED
    setCoderLedLL(led_v9_state);   // LED V9 (Min)
    setCoderLedHL(led_v12_state);  // LED V12 (Max)

    // 2. Aktualizace datab�ze appState (pro RTM)
    // POZN: appState nem� sloty pro V9/V12, pou?ijeme sloty v decoder_0
    app_state->decoder_0.isMin = led_v9_state;
    app_state->decoder_0.isMax = led_v12_state;
    
    // Ulo?�me i fin�ln� hodnotu (pro CMD 3)
    app_state->pwm_0.input = switched_val; // (pwm_0.input je dobr� m�sto pro fin�ln� hodnotu 0-255)
}
