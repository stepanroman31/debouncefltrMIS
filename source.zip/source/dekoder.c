// dek_decoder.c
#include "dekoder.h"

// Definice glob�ln�ho ?�ta?e
uint8_t s9_counter = 0;

// Statick� prom?nn� pro ulo?en� minul�ho stavu sign�l?
static uint8_t last_state = 0; // 00, 01, 10, 11

void initDecoder(void) {
    s9_counter = 0;
    last_state = 0; // P?edpokl�d�me start na 00
}

// Tato funkce mus� b�t vol�na periodicky (ka?dou 1ms)
void runDecoder(bool A_filtered, bool B_filtered) {
    
    // P?evedeme dva bool stavy na 2-bitov� ?�slo (0, 1, 2, nebo 3)
    uint8_t current_state = (A_filtered << 1) | B_filtered;

    // Zm?na nastala pouze pokud se stav li?� od minul�ho
    if (current_state != last_state) {
        
        // Logika pro ur?en� sm?ru (CW = po sm?ru hod. ru?i?ek)
        // CW p?echody: 00->01, 01->11, 11->10, 10->00
        if ( (last_state == 0 && current_state == 1) ||
             (last_state == 1 && current_state == 3) ||
             (last_state == 3 && current_state == 2) ||
             (last_state == 2 && current_state == 0) ) 
        {
            // Sm?r CW: Inkrementace (s kontrolou p?ete?en�)
            if (s9_counter < 255) {
                s9_counter++;
            }
        }
        // CCW p?echody: 00->10, 10->11, 11->01, 01->00
        else if ( (last_state == 0 && current_state == 2) ||
                  (last_state == 2 && current_state == 3) ||
                  (last_state == 3 && current_state == 1) ||
                  (last_state == 1 && current_state == 0) )
        {
            // Sm?r CCW: Dekrementace (s kontrolou podte?en�)
            if (s9_counter > 0) {
                s9_counter--;
            }
        }
        
        // Ulo?en� aktu�ln�ho stavu pro p?�?t� cyklus
        last_state = current_state;
    }
}
