#ifndef DEK_LOGIC_H
#define DEK_LOGIC_H

#include <stdint.h>
#include <stdbool.h>

/**
 * @brief P?epo?te hodnotu od potenciometru R1 z rozsahu <-2047, 2047> na rozsah <0, 255>. [cite: 114]
 * @param potValue Surov� hodnota z ADC.
 * @return P?epo?ten� hodnota 0-255.
 */
uint8_t recalculateR1(int16_t potValue);

/**
 * @brief Implementuje funkci p?ep�na?e mezi R1 a S9. [cite: 17]
 * @param S2_output Stav LED V2 (true = S9; false = R1). [cite: 119, 120]
 * @param r1_recalc P?epo?ten� hodnota z R1 (0-255).
 * @param s9_counter Hodnota ?�ta?e S9 (0-255).
 * @return Fin�ln� "p?epnut�" hodnota (0-255).
 */
uint8_t getSwitchedOutput(bool S2_output, uint8_t r1_recalc, uint8_t s9_counter);

/**
 * @brief Procedura pro ovl�d�n� LED V9 (Min) a V12 (Max) a aktualizaci datov�ho modelu.
 * Sv�t� V12 p?i 255 a V9 p?i 0. [cite: 121, 122]
 * @param switched_val Fin�ln� hodnota (0-255) z p?ep�na?e.
 */
void runLimitIndicators(uint8_t switched_val);

#endif // DEK_LOGIC_H
